import React from 'react'
import { Route, IndexRoute, Link  } from 'react-router'

import Home from            '../containers/Home'
import ProductIndex from    '../containers/Product'


export default function routes(store) {
  const validate = function (nextState, replaceState, callback) {
    // 需要做權限控制的時候開啟
    // const isLoggedIn = !!store.getState().auth.authenticated
    // if (!isLoggedIn) {
    //   replaceState(null, '/login')
    // }
    callback()
  }

  return (
    <Route>
      <Route path="/" component={Home} onEnter={validate}/>
      <Route path="/product" component={ProductIndex} />
    </Route>
  );
}