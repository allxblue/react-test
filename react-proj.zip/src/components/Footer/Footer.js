import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';

export default class Footer extends Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                Footer!!!
            </div>
        );
    };
};
