/**
 *   此為產品 產品分類Filter 元件
 */

import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';

export default class Filter extends Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                ProductFilter!!!
            </div>
        );
    };
};
