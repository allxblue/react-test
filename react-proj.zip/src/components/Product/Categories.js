/**
 *   此為產品 產品分類 元件
 */

import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';

export default class Categories extends Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                Categories!!!
            </div>
        );
    };
};
