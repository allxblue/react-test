/**
 *   此為 選單 元件
 */

import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';

export default class Header extends Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                Nav!!!
            </div>
        )
    };
};
