/**
 *   此為首頁 Banner-hero 元件
 */

import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';

export default class Banner_Hero extends Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                Banner_Hero!!!
            </div>
        );
    };
};
