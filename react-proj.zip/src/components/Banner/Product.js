/**
 *   此為首頁 Banner-產品 元件
 */

import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';

export default class Banner_Product extends Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                Banner_Product!!!
            </div>
        );
    };
};
