/**
 *   此為首頁 Banner-次要 元件
 */


import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';

export default class Banner_HomeSecond extends Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                Banner_HomeSecond!!!
            </div>
        );
    };
};
