/**
 *   此為 Header 元件
 */

import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';

// import { Nav, MemberNav } from 'components';
import Nav from 'components/Nav/Nav';
import MemberNav from 'components/MemberNav/MemberNav';


export default class Header extends Component {
  constructor() {
      super();
  }
  render() {
      return (
          <div>
          	header!!!
          	<Nav />
          	<MemberNav />
          </div>
      );
  };
};
