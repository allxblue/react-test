/**
 *   此為 會員選單 元件
 */

import React, { Component, PropTypes } from 'react';
import {connect} from 'react-redux';

export default class MemberNav extends Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                MemberNav!!!
            </div>
        );
    };
};
