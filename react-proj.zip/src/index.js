import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'


import configure from './store'
import route from './route'

const store = configure()

import { Router, Route, browserHistory } from 'react-router'
import { syncHistoryWithStore } from 'react-router-redux'
const history = syncHistoryWithStore(browserHistory, store)


/* 掛載處 */
const target = document.getElementById('root')

/* 預設輸出 */
class Root extends React.Component {
  render () {
    return (
      <div>
        <Provider store={store}>
          <div>
            <Router history={history} routes={route(store)}/>
          </div>
        </Provider>
      </div>

    )
  }
}

ReactDOM.render(<Root/>, target)