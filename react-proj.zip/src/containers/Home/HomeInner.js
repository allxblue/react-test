/**
 *   此為首頁內容容器
 */

import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import Banner_Hero from 			'components/Banner/Hero';
import Banner_Product from 		'components/Banner/Product';
import Banner_HomeSecond from 'components/Banner/HomeSecond';



export default class Home extends Component {
  render() {

  	return (
  		<div>
        <Banner_Hero />
        <Banner_Product />
        <Banner_HomeSecond />
  		</div>
  	)
	}
}