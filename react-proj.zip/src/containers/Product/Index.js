/**
 *   此為 產品首頁 容器
 */

import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import Header from    'components/Header/Header';
import Footer from    'components/Footer/Footer';
import Product from   'components/Product/Categories';



export default class Index extends Component {
  render() {

  	return (
  		<div className="home">
  			<Header />
  			<ProductCategories />
  			<Footer />
  			123
  		</div>
  	)
	}
}