/**
 *   此為 產品首頁內容 容器
 */

import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import Header from 								'components/Header/Header';
import Footer from 								'components/Footer/Footer';
import ProductIndexInner from 		'containers/Product/IndexInner';



export default class IndexInner extends Component {
  render() {

  	return (
  		<div className="IndexInner">
  			<ProductIndexInner />
  		</div>
  	)
	}
}